<?php

/*
 Template Name: Logout Request
 */

